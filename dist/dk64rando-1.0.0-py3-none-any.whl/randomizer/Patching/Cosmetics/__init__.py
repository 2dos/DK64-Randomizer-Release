"""Functions to write cosmetic data to ROM."""
