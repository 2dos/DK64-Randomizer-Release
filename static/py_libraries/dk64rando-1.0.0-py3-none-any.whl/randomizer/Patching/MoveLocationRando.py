"""Randomize Move Locations."""

from randomizer.Enums.Items import Items
from randomizer.Enums.Kongs import Kongs
from randomizer.Enums.Settings import MicrohintsEnabled, MoveRando
from randomizer.Enums.Types import Types
from randomizer.Lists.Item import ItemList
from randomizer.Patching.Patcher import LocalROM
from randomizer.Patching.Lib import setItemReferenceName
from randomizer.CompileHints import getHelmProgItems

# /* 0x0A7 */ char move_rando_on; // O = No Move Randomization. 1 = On.
# /* 0x0A8 */ unsigned char dk_crankymoves[7]; // First 4 bits indicates the moves type, 0 = Moves, 1 = Slam, 2 = Guns, 3 = Ammo Belt, 4 = Instrument, 0xF = No Upgrade. Last 4 bits indicate move level (eg. 1 = Baboon Blast, 2 = Strong Kong, 3 = Gorilla Grab). Each item in the array indicates the level it is given (eg. 1st slot is purchased in Japes, 2nd for Aztec etc.)
# /* 0x0AF */ unsigned char diddy_crankymoves[7]; // See "dk_crankymoves"
# /* 0x0B6 */ unsigned char lanky_crankymoves[7]; // See "dk_crankymoves"
# /* 0x0BD */ unsigned char tiny_crankymoves[7]; // See "dk_crankymoves"
# /* 0x0C4 */ unsigned char chunky_crankymoves[7]; // See "dk_crankymoves"
# /* 0x0CB */ unsigned char dk_funkymoves[7]; // See "dk_crankymoves"
# /* 0x0D2 */ unsigned char diddy_funkymoves[7]; // See "dk_crankymoves"
# /* 0x0D9 */ unsigned char lanky_funkymoves[7]; // See "dk_crankymoves"
# /* 0x0E0 */ unsigned char tiny_funkymoves[7]; // See "dk_crankymoves"
# /* 0x0E7 */ unsigned char chunky_funkymoves[7]; // See "dk_crankymoves"
# /* 0x0EE */ unsigned char dk_candymoves[7]; // See "dk_crankymoves". Note: Do not assign anything to item 0 or 4 as there's no Candy's in Japes or Fungi
# /* 0x0F5 */ unsigned char diddy_candymoves[7]; // See "dk_crankymoves". Note: Do not assign anything to item 0 or 4 as there's no Candy's in Japes or Fungi
# /* 0x0FC */ unsigned char lanky_candymoves[7]; // See "dk_crankymoves". Note: Do not assign anything to item 0 or 4 as there's no Candy's in Japes or Fungi
# /* 0x103 */ unsigned char tiny_candymoves[7]; // See "dk_crankymoves". Note: Do not assign anything to item 0 or 4 as there's no Candy's in Japes or Fungi
# /* 0x10A */ unsigned char chunky_candymoves[7]; // See "dk_crankymoves". Note: Do not assign anything to item 0 or 4 as there's no Candy's in Japes or Fungi

moveRandoOffset = 0x0A7

dk_crankymoves = []
diddy_crankymoves = []
lanky_crankymoves = []
tiny_crankymoves = []
chunky_crankymoves = []
dk_funkymoves = []
diddy_funkymoves = []
lanky_funkymoves = []
tiny_funkymoves = []
chunky_funkymoves = []
dk_candymoves = []
diddy_candymoves = []
lanky_candymoves = []
tiny_candymoves = []
chunky_candymoves = []

level_names = [
    "Jungle Japes",
    "Angry Aztec",
    "Frantic Factory",
    "Gloomy Galleon",
    "Fungi Forest",
    "Crystal Caves",
    "Creepy Castle",
    "DK Isles",
]

kong_names = {Kongs.donkey: "Donkey Kong", Kongs.diddy: "Diddy", Kongs.lanky: "Lanky", Kongs.tiny: "Tiny", Kongs.chunky: "Chunky", Kongs.any: "Any Kong"}


class MoveMicrohintItemData:
    """Information about the microhint move."""

    def __init__(self, subtype: str, index: int, kong: Kongs):
        """Initialize with given parameters."""
        self.subtype = subtype
        self.index = index
        self.kong = kong


move_info_data = {
    Items.BaboonBlast: MoveMicrohintItemData("special", 0, Kongs.donkey),
    Items.StrongKong: MoveMicrohintItemData("special", 1, Kongs.donkey),
    Items.GorillaGrab: MoveMicrohintItemData("special", 2, Kongs.donkey),
    Items.ChimpyCharge: MoveMicrohintItemData("special", 0, Kongs.diddy),
    Items.RocketbarrelBoost: MoveMicrohintItemData("special", 1, Kongs.diddy),
    Items.SimianSpring: MoveMicrohintItemData("special", 2, Kongs.diddy),
    Items.Orangstand: MoveMicrohintItemData("special", 0, Kongs.lanky),
    Items.BaboonBalloon: MoveMicrohintItemData("special", 1, Kongs.lanky),
    Items.OrangstandSprint: MoveMicrohintItemData("special", 2, Kongs.lanky),
    Items.MiniMonkey: MoveMicrohintItemData("special", 0, Kongs.tiny),
    Items.PonyTailTwirl: MoveMicrohintItemData("special", 1, Kongs.tiny),
    Items.Monkeyport: MoveMicrohintItemData("special", 2, Kongs.tiny),
    Items.HunkyChunky: MoveMicrohintItemData("special", 0, Kongs.chunky),
    Items.PrimatePunch: MoveMicrohintItemData("special", 1, Kongs.chunky),
    Items.GorillaGone: MoveMicrohintItemData("special", 2, Kongs.chunky),
    Items.ProgressiveSlam: MoveMicrohintItemData("slam", 1, Kongs.any),
    Items.Bongos: MoveMicrohintItemData("instrument", 0, Kongs.donkey),
    Items.Guitar: MoveMicrohintItemData("instrument", 0, Kongs.diddy),
    Items.Trombone: MoveMicrohintItemData("instrument", 0, Kongs.lanky),
    Items.Saxophone: MoveMicrohintItemData("instrument", 0, Kongs.tiny),
    Items.Triangle: MoveMicrohintItemData("instrument", 0, Kongs.chunky),
    Items.Coconut: MoveMicrohintItemData("gun", 0, Kongs.donkey),
    Items.Peanut: MoveMicrohintItemData("gun", 0, Kongs.diddy),
    Items.Grape: MoveMicrohintItemData("gun", 0, Kongs.lanky),
    Items.Feather: MoveMicrohintItemData("gun", 0, Kongs.tiny),
    Items.Pineapple: MoveMicrohintItemData("gun", 0, Kongs.chunky),
}


class MoveMicrohints:
    """Information about microhints."""

    def __init__(self, item: Items, file: int, enabled_hint_settings: list):
        """Initialize with given parameters."""
        self.item = item
        self.move = None
        if item in list(move_info_data.keys()):
            self.move = move_info_data[item]
        self.file = file
        self.enabled_hint_settings = enabled_hint_settings


def pushItemMicrohints(spoiler, move_dict: dict, level: int, kong: int, slot: int):
    """Push hint for the micro-hints system."""
    if spoiler.settings.microhints_enabled != MicrohintsEnabled.off:
        if kong != Kongs.any or slot == 0:
            move = None  # Using no item for the purpose of a default
            helm_prog_items = getHelmProgItems(spoiler)
            hinted_items = [
                # Key = Item, Value = Textbox index in text file 19
                MoveMicrohints(helm_prog_items[0], 26, [MicrohintsEnabled.base, MicrohintsEnabled.all]),
                MoveMicrohints(helm_prog_items[1], 25, [MicrohintsEnabled.base, MicrohintsEnabled.all]),
                MoveMicrohints(Items.Bongos, 27, [MicrohintsEnabled.all]),
                MoveMicrohints(Items.Triangle, 28, [MicrohintsEnabled.all]),
                MoveMicrohints(Items.Saxophone, 29, [MicrohintsEnabled.all]),
                MoveMicrohints(Items.Trombone, 30, [MicrohintsEnabled.all]),
                MoveMicrohints(Items.Guitar, 31, [MicrohintsEnabled.all]),
                MoveMicrohints(Items.ProgressiveSlam, 33, [MicrohintsEnabled.base, MicrohintsEnabled.all]),
            ]
            for item_data in hinted_items:
                move_data = item_data.move
                if (move_dict["move_type"] == move_data.subtype and move_dict["move_lvl"] == move_data.index and move_dict["move_kong"] == move_data.kong) or (
                    move_dict["move_type"] == move_data.subtype and move_data.subtype == "slam"
                ):
                    if spoiler.settings.microhints_enabled in list(item_data.enabled_hint_settings):
                        move = item_data
            if move is not None:
                data = {"textbox_index": move.file, "mode": "replace_whole", "target": spoiler.microhints[ItemList[move.item].name]}
                if 19 in spoiler.text_changes:
                    spoiler.text_changes[19].append(data)
                else:
                    spoiler.text_changes[19] = [data]


def writeMoveDataToROM(arr: list, enable_hints: bool, spoiler, kong_slot: int, kongs: list, level_override=None):
    """Write move data to ROM."""
    ROM_COPY = LocalROM()
    for xi, x in enumerate(arr):
        if x["move_type"] == "flag":
            flag_dict = {"dive": 0x182, "orange": 0x184, "barrel": 0x185, "vine": 0x183, "camera": 0x2FD, "shockwave": 0x179, "camera_shockwave": 0xFFFE}
            flag_index = 0xFFFF
            if x["flag"] in flag_dict:
                flag_index = flag_dict[x["flag"]]
            ROM_COPY.writeMultipleBytes(5 << 5, 1)
            ROM_COPY.writeMultipleBytes(x["price"], 1)
            ROM_COPY.writeMultipleBytes(flag_index, 2)
        elif x["move_type"] is None:
            ROM_COPY.writeMultipleBytes(7 << 5, 1)
            ROM_COPY.writeMultipleBytes(0, 1)
            ROM_COPY.writeMultipleBytes(0xFFFF, 2)
        else:
            move_types = ["special", "slam", "gun", "ammo_belt", "instrument"]
            data = move_types.index(x["move_type"]) << 5 | (x["move_lvl"] << 3) | x["move_kong"]
            price_var = 0
            if isinstance(x["price"], list):
                price_var = 0
            else:
                price_var = x["price"]
            ROM_COPY.writeMultipleBytes(data, 1)
            ROM_COPY.writeMultipleBytes(price_var, 1)
            ROM_COPY.writeMultipleBytes(0xFFFF, 2)
        if enable_hints:
            if level_override is not None:
                pushItemMicrohints(spoiler, x, level_override, kongs[xi], kong_slot)
            else:
                pushItemMicrohints(spoiler, x, xi, kongs[xi], kong_slot)


def dictEqual(dict1: dict, dict2: dict) -> bool:
    """Determine if two dictionaries are equal."""
    if len(dict1) != len(dict2):
        return False
    else:
        for i in dict1:
            if dict1.get(i) != dict2.get(i):
                return False
    return True


def randomize_moves(spoiler):
    """Randomize Move locations based on move_data from spoiler."""
    varspaceOffset = spoiler.settings.rom_data
    movespaceOffset = spoiler.settings.move_location_data
    hint_enabled = True
    if spoiler.settings.shuffle_items and Types.Shop in spoiler.settings.valid_locations:
        hint_enabled = False
    if spoiler.settings.move_rando != MoveRando.off and spoiler.move_data is not None:
        # Take a copy of move_data before modifying
        move_arrays = spoiler.move_data.copy()

        dk_crankymoves = move_arrays[0][0][0]
        diddy_crankymoves = move_arrays[0][0][1]
        lanky_crankymoves = move_arrays[0][0][2]
        tiny_crankymoves = move_arrays[0][0][3]
        chunky_crankymoves = move_arrays[0][0][4]
        dk_funkymoves = move_arrays[0][1][0]
        diddy_funkymoves = move_arrays[0][1][1]
        lanky_funkymoves = move_arrays[0][1][2]
        tiny_funkymoves = move_arrays[0][1][3]
        chunky_funkymoves = move_arrays[0][1][4]
        dk_candymoves = move_arrays[0][2][0]
        diddy_candymoves = move_arrays[0][2][1]
        lanky_candymoves = move_arrays[0][2][2]
        tiny_candymoves = move_arrays[0][2][3]
        chunky_candymoves = move_arrays[0][2][4]

        training_moves = move_arrays[1]
        bfi_move = move_arrays[2]

        kong_lists = []
        for shop in range(3):
            shop_lst = []
            for kong in range(5):
                kong_lst = []
                for level in range(8):
                    kong_lst.append([])
                shop_lst.append(kong_lst)
            kong_lists.append(shop_lst)
        for shop in range(3):
            for level in range(8):
                is_shared = True
                default = 0
                for kong in range(5):
                    if kong == 0:
                        default = move_arrays[0][shop][kong][level]
                    if not dictEqual(default, move_arrays[0][shop][kong][level]):
                        is_shared = False
                for kong in range(5):
                    applied_kong = kong
                    if is_shared:
                        applied_kong = Kongs.any
                    kong_lists[shop][kong][level] = applied_kong
        ROM_COPY = LocalROM()
        ROM_COPY.seek(varspaceOffset + moveRandoOffset)
        ROM_COPY.write(0x1)
        ROM_COPY.seek(movespaceOffset)
        writeMoveDataToROM(dk_crankymoves, hint_enabled, spoiler, 0, kong_lists[0][0])
        writeMoveDataToROM(diddy_crankymoves, hint_enabled, spoiler, 1, kong_lists[0][1])
        writeMoveDataToROM(lanky_crankymoves, hint_enabled, spoiler, 2, kong_lists[0][2])
        writeMoveDataToROM(tiny_crankymoves, hint_enabled, spoiler, 3, kong_lists[0][3])
        writeMoveDataToROM(chunky_crankymoves, hint_enabled, spoiler, 4, kong_lists[0][4])
        writeMoveDataToROM(dk_funkymoves, hint_enabled, spoiler, 0, kong_lists[1][0])
        writeMoveDataToROM(diddy_funkymoves, hint_enabled, spoiler, 1, kong_lists[1][1])
        writeMoveDataToROM(lanky_funkymoves, hint_enabled, spoiler, 2, kong_lists[1][2])
        writeMoveDataToROM(tiny_funkymoves, hint_enabled, spoiler, 3, kong_lists[1][3])
        writeMoveDataToROM(chunky_funkymoves, hint_enabled, spoiler, 4, kong_lists[1][4])
        writeMoveDataToROM(dk_candymoves, hint_enabled, spoiler, 0, kong_lists[2][0])
        writeMoveDataToROM(diddy_candymoves, hint_enabled, spoiler, 1, kong_lists[2][1])
        writeMoveDataToROM(lanky_candymoves, hint_enabled, spoiler, 2, kong_lists[2][2])
        writeMoveDataToROM(tiny_candymoves, hint_enabled, spoiler, 3, kong_lists[2][3])
        writeMoveDataToROM(chunky_candymoves, hint_enabled, spoiler, 4, kong_lists[2][4])
        writeMoveDataToROM(training_moves, hint_enabled, spoiler, 0, [Kongs.any, Kongs.any, Kongs.any, Kongs.any], 7)
        writeMoveDataToROM(bfi_move, hint_enabled, spoiler, 0, [Kongs.tiny], 7)


def getNextSlot(spoiler, item: Items) -> int:
    """Get slot for progressive item with pre-given moves."""
    slots = []
    if item == Items.ProgressiveAmmoBelt:
        slots = [0x1C, 0x1D]
    elif item == Items.ProgressiveInstrumentUpgrade:
        slots = [0x20, 0x21, 0x22]
    elif item == Items.ProgressiveSlam:
        slots = [0xF, 0x10, 0x11]
    if len(slots) == 0:
        return None
    ROM_COPY = LocalROM()
    for slot in slots:
        offset = int(slot >> 3)
        check = int(slot % 8)
        ROM_COPY.seek(spoiler.settings.rom_data + 0xD5 + offset)
        val = int.from_bytes(ROM_COPY.readBytes(1), "big")
        if (val & (0x80 >> check)) == 0:
            return slot
    return None


def place_pregiven_moves(spoiler):
    """Place pre-given moves."""
    item_order = [
        Items.BaboonBlast,
        Items.StrongKong,
        Items.GorillaGrab,
        Items.ChimpyCharge,
        Items.RocketbarrelBoost,
        Items.SimianSpring,
        Items.Orangstand,
        Items.BaboonBalloon,
        Items.OrangstandSprint,
        Items.MiniMonkey,
        Items.PonyTailTwirl,
        Items.Monkeyport,
        Items.HunkyChunky,
        Items.PrimatePunch,
        Items.GorillaGone,
        Items.ProgressiveSlam,
        Items.ProgressiveSlam,
        Items.ProgressiveSlam,
        Items.Coconut,
        Items.Peanut,
        Items.Grape,
        Items.Feather,
        Items.Pineapple,
        Items.Bongos,
        Items.Guitar,
        Items.Trombone,
        Items.Saxophone,
        Items.Triangle,
        Items.ProgressiveAmmoBelt,
        Items.ProgressiveAmmoBelt,
        Items.HomingAmmo,
        Items.SniperSight,
        Items.ProgressiveInstrumentUpgrade,
        Items.ProgressiveInstrumentUpgrade,
        Items.ProgressiveInstrumentUpgrade,
        Items.Swim,
        Items.Oranges,
        Items.Barrels,
        Items.Vines,
        Items.Camera,
        Items.Shockwave,
    ]
    ROM_COPY = LocalROM()
    progressives = (Items.ProgressiveAmmoBelt, Items.ProgressiveInstrumentUpgrade, Items.ProgressiveSlam)
    name_str = "Extra Training"
    for item in spoiler.pregiven_items:
        # print(item)
        if item is not None and item != Items.NoItem:
            new_slot = None
            if item in progressives:
                new_slot = getNextSlot(spoiler, item)
            elif item in item_order:
                new_slot = item_order.index(item)
            elif item == Items.CameraAndShockwave:
                new_slot = None  # Setting is handled by the code below
                for index in [item_order.index(Items.Camera), item_order.index(Items.Shockwave)]:
                    offset = int(index >> 3)
                    check = int(index % 8)
                    ROM_COPY.seek(spoiler.settings.rom_data + 0xD5 + offset)
                    val = int.from_bytes(ROM_COPY.readBytes(1), "big")
                    val |= 0x80 >> check
                    ROM_COPY.seek(spoiler.settings.rom_data + 0xD5 + offset)
                    ROM_COPY.writeMultipleBytes(val, 1)
            if new_slot is not None:
                offset = int(new_slot >> 3)
                check = int(new_slot % 8)
                ROM_COPY.seek(spoiler.settings.rom_data + 0xD5 + offset)
                val = int.from_bytes(ROM_COPY.readBytes(1), "big")
                val |= 0x80 >> check
                ROM_COPY.seek(spoiler.settings.rom_data + 0xD5 + offset)
                ROM_COPY.writeMultipleBytes(val, 1)
        if item == Items.ProgressiveAmmoBelt:
            setItemReferenceName(spoiler, item, new_slot - 0x1C, name_str)
        elif item == Items.ProgressiveInstrumentUpgrade:
            setItemReferenceName(spoiler, item, new_slot - 0x20, name_str)
        elif item == Items.ProgressiveSlam:
            setItemReferenceName(spoiler, item, new_slot - 0xF, name_str)
        else:
            setItemReferenceName(spoiler, item, 0, name_str)
