"""Init file for folder mapping."""
