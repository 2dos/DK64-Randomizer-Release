"""Functions to write data to ROM."""
