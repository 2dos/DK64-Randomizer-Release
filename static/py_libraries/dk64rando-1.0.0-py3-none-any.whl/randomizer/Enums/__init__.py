"""Enum data for item types."""
