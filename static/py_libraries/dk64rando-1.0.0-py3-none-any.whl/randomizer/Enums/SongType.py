'Enum for Song Types.'
from enum import IntEnum,auto
class SongType(IntEnum):'Enum data for what type of song you are playing.\n\n    Args:\n            IntEnum (int): Enum of the song.\n    ';System=auto();BGM=auto();Fanfare=auto();Ambient=auto();Event=auto()